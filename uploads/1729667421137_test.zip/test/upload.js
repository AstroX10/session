const axios = require('axios');
const FormData = require('form-data');
const fs = require('fs');
const form = new FormData();
form.append('file', fs.createReadStream('./path/to/your/file.zip'));
axios.post('http://localhost:3000/api/upload', form, { headers: form.getHeaders() })
  .then(res => console.log(res.data))
  .catch(err => console.error('Error:', err));
