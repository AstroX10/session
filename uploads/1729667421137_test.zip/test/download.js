const axios = require('axios');
const fs = require('fs');
const sessionKey = 'XSTRO_25_82_91';
axios.post('http://localhost:3000/api/download', { sessionKey }, { responseType: 'stream' })
  .then(res => {
    const writer = fs.createWriteStream('./path/to/save/downloaded.zip');
    res.data.pipe(writer);
    writer.on('finish', () => console.log('File downloaded successfully'));
  })
  .catch(err => console.error('Error:', err));
